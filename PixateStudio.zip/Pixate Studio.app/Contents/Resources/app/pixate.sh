#!/bin/bash

while getopts ":fvh-:" opt; do
  case "$opt" in
    -)
      case "${OPTARG}" in
        help|version)
          REDIRECT_STDERR=1
          EXPECT_OUTPUT=1
          ;;
      esac
      ;;
    h|v)
      REDIRECT_STDERR=1
      EXPECT_OUTPUT=1
      ;;
  esac
done

if [ $REDIRECT_STDERR ]; then
  exec 2> /dev/null
fi

PIXATE_PATH="${PIXATE_PATH:-/Applications}"
PIXATE_APP_NAME="Pixate Studio.app"

if [ ! -x "$PIXATE_PATH/$PIXATE_APP_NAME" ]; then
  PIXATE_PATH="$(mdfind "kMDItemCFBundleIdentifier == 'com.pixate.studio'" | grep -v ShipIt | head -1 | xargs -0 dirname)"
fi

if [ -z "$PIXATE_PATH" ]; then
  echo "Cannot locate Pixate Studio.app, it is usually located in /Applications. Set the PIXATE_PATH environment variable to the directory containing Pixate Desktop.app."
  exit 1
fi

if [ $EXPECT_OUTPUT ]; then
  "$PIXATE_PATH/$PIXATE_APP_NAME/Contents/MacOS/Atom" "$@"
  exit $?
else
  open -a "$PIXATE_PATH/$PIXATE_APP_NAME" "$@"
fi
