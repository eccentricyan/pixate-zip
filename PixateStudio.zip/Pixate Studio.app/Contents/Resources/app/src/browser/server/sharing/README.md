# Prototype Sharing in Studio

## Authenticating for Test Purposes

For testing the IPC calls below you will need to be authenticated with the production Pixate service.

Since all Cocoa apps, by default, share the same cookie storage, you can simply log in to the Pixate service (`app.pixate.com`) using your browser. 

## IPC calls Editor<->Studio

Editor sends the request messages and should listen for the `...-reply` messages.  Studio vice-versa.

* `app:fetch-auth-status` and `app:fetch-auth-status-reply`
No arguments expected from the Editor.  Studio's reply message will have an object with either an `error` member (in case of true communications errors, etc.) or an `authenticated` member which is boolean `true` or `false`.

* `app:fetch-service-user` and `app:fetch-service-user-reply`
This is for information about the authenticated user.
No arguments are expected from the Editor. Studio's reply message will have an object with either an `error` member (with `error.statusCode` for an HTTP status code) or with `user` and `account` members. See later example.

* `app:fetch-service-projects` and `app:fetch-service-projects-reply`
This is for information about Pixate Service projects available to the authenticated user.
No arguments are expected from the Editor. Studio's reply message will either be an object with either an `error` member (with `error.statusCode` for an HTTP status code) or it will be an array of project objects. See later example.

## Reply object examples

### User

     {
          account: {
               is_delinquent: false,
               plan: 'premium_monthly',
               screenCount: 248,
               is_academic_plan: false,
               owner: 'all@pixate.com',
               stripeId: 'cus_4a1V4rTUYqg2GS',
               _id: '53666403f9f767ec41332a47',
               is_free_plan: false,
               is_personal_plan: false,
               projectLimit: 1000000,
               createdAt: '2014-05-04T16:00:03.000Z',
               is_locked_out: false,
               name: 'Pixate',
               projectCount: 20,
               updatedAt: '2014-10-16T20:45:46.597Z',
               is_trialing: false,
               id: '53666403f9f767ec41332a47',
               lockedScreens: [],
               is_premium_plan: true,
               screenLimit: 1000000
          },
          user: {
               email: 'bill@pixate.com',
               updatedAt: '2015-06-18T20:21:28.636Z',
               roles: ['user'],
               identity: {
                    moniker: 'BD',
                    theme: [Object]
               },
               full_name: 'Bill Dawson',
               has_viewed_prototype: true,
               active: true,
               login: '2015-06-18T20:21:54.549Z',
               has_used_mobile_app: true,
               _id: '53a07551a105b96b76cd1aeb',
               license: '552bf4046e13f70300176d39',
               id: '53a07551a105b96b76cd1aeb',
               referrals_remaining: 2,
               has_seen_welcome: true,
               first_name: 'Bill',
               account: '53666403f9f767ec41332a47',
               invite_email: null,
               last_name: 'Dawson',
               name: ''
          }
     }

### Projects

     [ { _id: '557f424381a134ddb00b0795',
         name: 'Set-bug',
         createdAt: '2015-06-15T21:23:15.000Z',
         updatedAt: '2015-06-15T23:23:39.480Z',
         creator: '53666403f9f767ec41332a48',
         account: '53666403f9f767ec41332a47',
         isSample: false,
         isPrivate: false,
         id: '557f424381a134ddb00b0795',
         screens:
          [ [Object],
            [Object],
            [Object],
            [Object],
            [Object],
            [Object],
            [Object],
            [Object],
            [Object] ],
         permissions: [] },
       { _id: '557b3780b111f0a4ff3f9af1',
         name: 'Goog Demo',
         createdAt: '2015-06-12T19:48:16.000Z',
         updatedAt: '2015-06-12T19:48:22.973Z',
         creator: '53666403f9f767ec41332a48',
         account: '53666403f9f767ec41332a47',
         isSample: false,
         isPrivate: false,
         id: '557b3780b111f0a4ff3f9af1',
         screens: [ [Object], [Object] ],
         permissions: [] },
       { _id: '553967831603b7ad3f8e4765',
         name: 'Eugene',
         createdAt: '2015-04-23T21:43:31.000Z',
         updatedAt: '2015-04-23T21:43:31.000Z',
         account: '53666403f9f767ec41332a47',
         isSample: false,
         isPrivate: false,
         id: '553967831603b7ad3f8e4765',
         screens: [ [Object], [Object], [Object] ],
         permissions: [] } ]