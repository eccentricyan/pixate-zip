DROP TABLE IF EXISTS "versions";
CREATE TABLE "versions" (
    "created_at" INTEGER,
    "number" INTEGER
);
INSERT INTO "versions" VALUES(strftime("%s","now"), 1);

DROP TABLE IF EXISTS "users";
CREATE TABLE "users" (
    "id" TEXT(24) NOT NULL PRIMARY KEY,
    "type" TEXT,
    "name" TEXT,
    "status" TEXT,
    "created_at" INTEGER,
    "accessed_at" INTEGER,
    "host" TEXT,
    "port" INTEGER
);
