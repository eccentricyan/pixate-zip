# Initiate a merge

```
POST /api/components?access_key=<access-key>
```

It is expected that the full path to the `.pixate` file being merged will exist
in a `path` field in the upload form (`req.body.path` on the server).

If the POST is successful, then a JSON object like the following will be
returned:

```Javascript
{
    "status": "merged"
}
```

If the POST fails, then a JSON object like the following will be returned:

```Javascript
{
    "status": "error",
    "message": "...some error message here..."
}
```

Possible status codes: 200, 401, 500
